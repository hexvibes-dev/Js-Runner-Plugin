"use strict";(()=>{window.acode.setPluginInit("js-runner",(x,D,M)=>{let g=window.editorManager,d=null,u=null;(function(){let n=`
      #js-runner-btn {
        position: fixed;
        right: 20px;
        bottom: 20px;
        z-index: 9999;
        background: #f7df1e;
        color: #000;
        padding: 12px;
        border-radius: 50%;
        font-weight: bold;
        box-shadow: 0 6px 18px rgba(0,0,0,0.25);
        cursor: pointer;
        display:flex;
        align-items:center;
        justify-content:center;
        width:52px;
        height:52px;
        user-select:none;
        touch-action: none;
      }
      #js-runner-btn:active { transform: scale(0.98); }

      #js-runner-modal {
        position: fixed;
        left: 6%;
        top: 8%;
        width: 88%;
        height: 76%;
        background: #282c34;
        color: #abb2bf;
        z-index: 10000;
        padding: 10px;
        border-radius: 10px;
        box-shadow: 0 12px 40px rgba(0,0,0,0.6);
        display: flex;
        flex-direction: column;
        -webkit-font-smoothing:antialiased;
      }

      .js-runner-header { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:8px; cursor: move; }
      .js-runner-accent { background:#2AABEE; color:#fff; padding:6px 10px; border-radius:6px; font-weight:600; }
      #js-runner-output { flex:1; overflow:auto; background:#1e2228; padding:10px; border-radius:8px; border:1px solid #3b3f46; font-family: monospace; font-size:13px; color:#d6deeb; }
      .js-runner-output-line { padding:4px 6px; white-space:pre-wrap; word-break:break-word; }
      .js-runner-output-line.err { color:#e06c75; }
      .js-runner-output-line.warn { color:#e5c07b; }

      .js-runner-input-area { display:flex; margin-top:8px; gap:8px; align-items:center; }
      .js-runner-input { flex:1; padding:10px; border-radius:8px; border:1px solid #3b3f46; background:#23272b; color:#abb2bf; font-family: monospace; }
      .js-runner-run { padding:10px 12px; border-radius:8px; background:#2AABEE; color:#fff; border:none; cursor:pointer; }
      .js-runner-clear { padding:10px 12px; border-radius:8px; background:#e06c75; color:#fff; border:none; cursor:pointer; }
      .js-runner-small { padding:6px 8px; border-radius:6px; background:transparent; color:#abb2bf; border:1px solid rgba(255,255,255,0.04); cursor:pointer; }

      /* Suggestion boxes (ensure visible above editor UI) */
      .js-runner-suggestions, .js-runner-input-suggestions {
        position: fixed;
        background: #1e2228;
        color: #d6deeb;
        border: 1px solid #3b3f46;
        border-radius: 6px;
        padding: 6px 0;
        min-width: 160px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.6);
        font-family: monospace;
        font-size: 13px;
        z-index: 12000;
        max-height: 260px;
        overflow: auto;
        pointer-events: auto;
      }
      .js-runner-suggestion, .js-runner-input-suggestion {
        padding: 6px 10px;
        cursor: pointer;
        white-space: nowrap;
      }
      .js-runner-suggestion.active, .js-runner-input-suggestion.active {
        background: rgba(42,171,238,0.12);
        color: #e6eef6;
      }
    `,o=document.createElement("style");o.id="js-runner-styles",o.textContent=n,document.head.appendChild(o)})();function v(e,n){u||y();let o=u.querySelector("#js-runner-output"),r=document.createElement("div");r.className="js-runner-output-line"+(n?" "+n:""),r.textContent=e,o.appendChild(r),o.scrollTop=o.scrollHeight}function k(){if(!u)return;let e=u.querySelector("#js-runner-output");e.innerHTML=""}function m(){window.origConsole||(window.origConsole={log:console.log,error:console.error,warn:console.warn},console.log=function(...e){try{window.origConsole.log.apply(window.origConsole,e)}catch{}v(e.map(n=>typeof n=="object"?JSON.stringify(n):String(n)).join(" "))},console.error=function(...e){try{window.origConsole.error.apply(window.origConsole,e)}catch{}v(e.map(n=>typeof n=="object"?JSON.stringify(n):String(n)).join(" "),"err")},console.warn=function(...e){try{window.origConsole.warn.apply(window.origConsole,e)}catch{}v(e.map(n=>typeof n=="object"?JSON.stringify(n):String(n)).join(" "),"warn")})}function C(){if(window.origConsole){try{console.log=window.origConsole.log,console.error=window.origConsole.error,console.warn=window.origConsole.warn}catch{}window.origConsole=null}}function b(){if(d)return;d=document.createElement("div"),d.id="js-runner-btn",d.innerText="JS",document.body.appendChild(d);let e=0,n=0,o=0,r=0,i=!1,l=6,t=null;function s(a){if(a.pointerType==="mouse"&&a.button!==0)return;t=a.pointerId;try{d.setPointerCapture(t)}catch{}e=a.clientX,n=a.clientY;let w=d.getBoundingClientRect();o=e-w.left,r=n-w.top,i=!1,document.addEventListener("pointermove",c),document.addEventListener("pointerup",f),document.addEventListener("pointercancel",p)}function c(a){if(a.pointerId!==t)return;let w=Math.abs(a.clientX-e),h=Math.abs(a.clientY-n);(w>l||h>l)&&(i=!0),d.style.position="fixed",d.style.left=a.clientX-o+"px",d.style.top=a.clientY-r+"px",d.style.right="auto",d.style.bottom="auto"}function f(a){if(a.pointerId!==t)return;try{d.releasePointerCapture(t)}catch{}document.removeEventListener("pointermove",c),document.removeEventListener("pointerup",f),document.removeEventListener("pointercancel",p);let w=i;setTimeout(()=>{i=!1},50),w||y(),t=null}function p(a){if(a.pointerId===t){try{d.releasePointerCapture(t)}catch{}document.removeEventListener("pointermove",c),document.removeEventListener("pointerup",f),document.removeEventListener("pointercancel",p),t=null,i=!1}}d.addEventListener("pointerdown",s,{passive:!0}),d.tabIndex=0,d.addEventListener("keydown",a=>{(a.key==="Enter"||a.key===" ")&&y()})}function L(){d&&(d.remove(),d=null)}function y(){if(u)return;u=document.createElement("div"),u.id="js-runner-modal",u.className="js-runner-modal",u.innerHTML=`
      <div class="js-runner-header" id="js-runner-header">
        <div style="display:flex;align-items:center;gap:12px">
          <span class="js-runner-accent">JS Runner</span>
          <span style="opacity:.85;font-size:13px">Console</span>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <button id="js-runner-clear" class="js-runner-clear">Limpiar</button>
          <button id="js-runner-close" class="js-runner-small">Cerrar</button>
        </div>
      </div>
      <div id="js-runner-output"></div>
      <div class="js-runner-input-area">
        <input id="js-runner-input" class="js-runner-input" placeholder="Escribe una expresi\xF3n y pulsa Enter" />
        <button id="js-runner-run" class="js-runner-run" type="button">Run</button>
      </div>
    `,document.body.appendChild(u);let e=u.querySelector("#js-runner-clear"),n=u.querySelector("#js-runner-close"),o=u.querySelector("#js-runner-run");e.addEventListener("click",t=>{t.stopPropagation(),k()}),n.addEventListener("click",t=>{t.stopPropagation(),I()}),o.addEventListener("click",t=>{t.stopPropagation();try{let s=u.querySelector("#js-runner-input");if(!s)return;let c=s.value.trim();c&&(window.origConsole||m(),j(c),s.value="",window.hideInputSuggestions&&window.hideInputSuggestions())}catch(s){try{console.error(s&&s.stack?s.stack:String(s))}catch{}}});let r=u.querySelector("#js-runner-input");r.addEventListener("keydown",J),r.addEventListener("beforeinput",R);let i=r.value;r.addEventListener("input",()=>{window.triggerInputSuggestions&&window.triggerInputSuggestions(r);try{let t=r.value,s=t.length-i.length;if(s>0){let c=t.slice(r.selectionStart-s,r.selectionStart),f={"(":")","{":"}","[":"]",'"':'"',"'":"'","":""};if(c&&c.length===1&&f[c]){let p=r.selectionStart;t[p]!==f[c]&&(r.value=t.slice(0,p)+f[c]+t.slice(p),r.setSelectionRange(p,p))}}}catch{}i=r.value}),r.addEventListener("blur",()=>setTimeout(()=>{window.hideInputSuggestions&&window.hideInputSuggestions()},150)),m();let l=u.querySelector("#js-runner-header");B(u,l),P(()=>{setTimeout(()=>{if(window.initJsRunnerEnhancements)try{window.initJsRunnerEnhancements(g)}catch{}try{typeof S=="function"&&S()}catch{}},80)})}function I(){u&&(C(),u.remove(),u=null)}function q(){try{let e=g&&g.editor,n="";if(e&&(typeof e.getValue=="function"?n=String(e.getValue()):e.session&&typeof e.session.getValue=="function"&&(n=String(e.session.getValue()))),!n||!n.trim()){v("No hay c\xF3digo en el editor para ejecutar.","warn");return}u||y(),window.origConsole||m();try{new Function(n)()}catch(o){console.error(o&&o.stack?o.stack:String(o))}}catch(e){try{console.error(e&&e.stack?e.stack:String(e))}catch{}}}function S(){try{let e=window.editorManager,n=e&&e.editor;if(!n)return;let o="";if(typeof n.getValue=="function"?o=String(n.getValue()):n.session&&typeof n.session.getValue=="function"&&(o=String(n.session.getValue())),!o.trim()){console.warn("No hay c\xF3digo en el editor para ejecutar.");return}!window.origConsole&&typeof m=="function"&&m(),new Function(o)()}catch(e){console.error(e&&e.stack?e.stack:String(e))}}function j(e){try{u||y(),window.origConsole||m();try{let n=new Function('"use strict"; return ('+e+")")();typeof n<"u"&&v(String(n))}catch{try{new Function(e)()}catch(o){console.error(o&&o.stack?o.stack:String(o))}}}catch(n){console.error(n&&n.stack?n.stack:String(n))}}function R(e){try{let n=e.target,o={"(":")","{":"}","[":"]",'"':'"',"'":"'","":""};if(e.inputType==="insertText"&&e.data&&o[e.data]&&!e.ctrlKey&&!e.metaKey&&!e.altKey){e.preventDefault();let r=n.selectionStart,i=n.selectionEnd,l=e.data,t=o[l];if(r!==i){let s=n.value.slice(r,i);n.value=n.value.slice(0,r)+l+s+t+n.value.slice(i),n.setSelectionRange(r+1,i+1)}else n.value=n.value.slice(0,r)+l+t+n.value.slice(r),n.setSelectionRange(r+1,r+1);window.triggerInputSuggestions&&window.triggerInputSuggestions(n)}}catch{}}function J(e){let n=e.target,o=window.jsRunner_inputSuggestionBox;if(o&&o.style.display==="block"){let i=Array.from(o.querySelectorAll(".js-runner-input-suggestion")),l=o.querySelector(".active"),t=l?i.indexOf(l):-1;if(e.key==="ArrowDown"){e.preventDefault(),t=t<i.length-1?t+1:0,i.forEach(s=>s.classList.remove("active")),i[t].classList.add("active");return}else if(e.key==="ArrowUp"){e.preventDefault(),t=t>0?t-1:i.length-1,i.forEach(s=>s.classList.remove("active")),i[t].classList.add("active");return}else if(e.key==="Enter"){let s=t===-1?i[0]:i[t];if(s){e.preventDefault();let c=window.normalizeInputSuggestion?window.normalizeInputSuggestion(s.textContent):s.textContent.toLowerCase();n.value=c,T(n),window.hideInputSuggestions&&window.hideInputSuggestions();return}}else if(e.key==="Escape"){window.hideInputSuggestions&&window.hideInputSuggestions();return}}let r={"(":")","{":"}","[":"]",'"':'"',"'":"'","":""};if(e.key in r&&!e.ctrlKey&&!e.metaKey&&!e.altKey){e.preventDefault();let i=n.selectionStart,l=n.selectionEnd,t=e.key,s=r[t];if(i!==l){let c=n.value.slice(i,l);n.value=n.value.slice(0,i)+t+c+s+n.value.slice(l),n.setSelectionRange(i+1,l+1)}else n.value=n.value.slice(0,i)+t+s+n.value.slice(i),n.setSelectionRange(i+1,i+1);window.triggerInputSuggestions&&window.triggerInputSuggestions(n);return}if(e.key==="Enter"){e.preventDefault();let i=n.value.trim();i&&(j(i),n.value="",window.hideInputSuggestions&&window.hideInputSuggestions())}}function T(e){try{let n=e.value,o=e.selectionStart,r=n.lastIndexOf("(",o);r===-1&&(r=n.indexOf("(")),r!==-1&&(e.setSelectionRange(r+1,r+1),e.focus())}catch{}}function B(e,n){if(!e||!n)return;let o=0,r=0,i=0,l=0;n.style.cursor="move",n.addEventListener("mousedown",t=>{o=t.clientX,r=t.clientY;let s=e.getBoundingClientRect();i=s.left,l=s.top;function c(p){e.style.left=i+(p.clientX-o)+"px",e.style.top=l+(p.clientY-r)+"px",e.style.right="auto",e.style.bottom="auto",e.style.position="fixed"}function f(){document.removeEventListener("mousemove",c),document.removeEventListener("mouseup",f)}document.addEventListener("mousemove",c),document.addEventListener("mouseup",f)}),n.addEventListener("touchstart",t=>{if(!t.touches||!t.touches[0])return;let s=t.touches[0];o=s.clientX,r=s.clientY;let c=e.getBoundingClientRect();i=c.left,l=c.top;function f(a){if(!a.touches||!a.touches[0])return;let w=a.touches[0];e.style.left=i+(w.clientX-o)+"px",e.style.top=l+(w.clientY-r)+"px",e.style.right="auto",e.style.bottom="auto",e.style.position="fixed"}function p(){document.removeEventListener("touchmove",f),document.removeEventListener("touchend",p)}document.addEventListener("touchmove",f,{passive:!1}),document.addEventListener("touchend",p)},{passive:!0})}function P(e){let n=(typeof x=="string"?x:"")+"enhancements.js";if(window.initJsRunnerEnhancements){try{e()}catch{e()}return}let o=document.createElement("script");o.src=n,o.onload=()=>e(),o.onerror=()=>e(),document.head.appendChild(o)}function E(){let e=g.activeFile;return e&&e.filename&&e.filename.endsWith(".js")}try{g&&g.editor&&window.initJsRunnerEnhancements&&window.initJsRunnerEnhancements(g),g.on("switch-file",()=>{setTimeout(()=>{window.initJsRunnerEnhancements&&window.initJsRunnerEnhancements(g)},120)})}catch{}g.on("switch-file",()=>{E()?b():L()});try{E()&&b()}catch{}});})();
